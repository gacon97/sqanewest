/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author nam
 */
public class CaculateInterest {
    private int thang;
    private ArrayList<Integer> tienGocConLai;
    private ArrayList<Integer> tienLaiTraHangThang;
    private Integer gocTraHangThang;
    private ArrayList<Integer> tongTienTraHangThang;

    public int getThang() {
        return thang;
    }

    public void setThang(int thang) {
        this.thang = thang;
    }

    public ArrayList<Integer> getTienGocConLai() {
        return tienGocConLai;
    }

    public void setTienGocConLai(ArrayList<Integer> tienGocConLai) {
        this.tienGocConLai = tienGocConLai;
    }

    public ArrayList<Integer> getTienLaiTraHangThang() {
        return tienLaiTraHangThang;
    }

    public void setTienLaiTraHangThang(ArrayList<Integer> tienLaiTraHangThang) {
        this.tienLaiTraHangThang = tienLaiTraHangThang;
    }

    public Integer getGocTraHangThang() {
        return gocTraHangThang;
    }

    public void setGocTraHangThang(Integer gocTraHangThang) {
        this.gocTraHangThang = gocTraHangThang;
    }

    public ArrayList<Integer> getTongTienTraHangThang() {
        return tongTienTraHangThang;
    }

    public void setTongTienTraHangThang(ArrayList<Integer> tongTienTraHangThang) {
        this.tongTienTraHangThang = tongTienTraHangThang;
    }

}
